import React from 'react';
import { X, Shield, Zap, Code2, Lock, Sparkles, Cpu } from 'lucide-react';

interface FeaturesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function FeaturesModal({ isOpen, onClose }: FeaturesModalProps) {
  if (!isOpen) return null;

  const features = [
    {
      icon: <Shield className="w-6 h-6 text-blue-400" />,
      title: "100% Undetectable",
      description: "Our advanced protection system ensures complete undetectability"
    },
    {
      icon: <Cpu className="w-6 h-6 text-blue-400" />,
      title: "Next-Gen Technology",
      description: "Using cutting-edge injection methods for maximum compatibility"
    },
    {
      icon: <Code2 className="w-6 h-6 text-blue-400" />,
      title: "Premium Scripts",
      description: "Access to exclusive, high-performance script library"
    },
    {
      icon: <Lock className="w-6 h-6 text-blue-400" />,
      title: "Secure Updates",
      description: "Regular updates to maintain security and compatibility"
    },
    {
      icon: <Sparkles className="w-6 h-6 text-blue-400" />,
      title: "Advanced Console",
      description: "Professional debugging tools for script development"
    },
    {
      icon: <Zap className="w-6 h-6 text-blue-400" />,
      title: "Ultra-Fast Execution",
      description: "Lightning-fast script execution engine"
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ease-in-out"
        onClick={onClose}
        style={{ animation: 'fadeIn 0.3s ease-in-out' }}
      />
      <div 
        className="relative z-10 bg-[#040B1C] border border-blue-500/20 rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto transform transition-all duration-300 ease-out"
        style={{ animation: 'slideIn 0.3s ease-out' }}
      >
        <div className="sticky top-0 bg-[#040B1C]/80 backdrop-blur-sm border-b border-blue-500/20 p-4 flex justify-between items-center">
          <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-blue-300 bg-clip-text text-transparent">
            Premium Features
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-blue-500/10 rounded-lg transition-colors"
          >
            <X className="w-6 h-6 text-blue-400" />
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className="p-6 rounded-xl bg-blue-950/50 border border-blue-500/20 hover:border-blue-500/40 transition-all transform hover:scale-[1.02] duration-200"
              style={{ animation: `fadeSlideIn 0.3s ease-out forwards ${index * 0.1}s` }}
            >
              <div className="mb-4 inline-flex p-3 bg-blue-500/10 rounded-lg">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
              <p className="text-blue-200/70">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}