import React, { useState, useEffect } from 'react';
import { FeaturesModal } from './FeaturesModal';

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <header 
        className={`fixed w-full top-0 z-50 transition-all duration-300 ${
          isScrolled ? 'py-4 bg-[#040B1C]/80 backdrop-blur-xl border-b border-blue-500/20' : 'py-6'
        }`}
      >
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <span className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-blue-500 bg-clip-text text-transparent">
              Solaris
            </span>
            
            <nav className="flex items-center gap-6">
              <button 
                onClick={() => setIsModalOpen(true)}
                className="text-blue-300 hover:text-blue-400 transition-colors"
              >
                Features
              </button>
              <a 
                href="https://discord.gg/kBkwdQxtH8" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-blue-300 hover:text-blue-400 transition-colors"
              >
                Discord
              </a>
            </nav>
          </div>
        </div>
      </header>

      <FeaturesModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  );
}