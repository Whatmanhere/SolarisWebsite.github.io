import React from 'react';
import { Users, MessageSquare, Github } from 'lucide-react';

export function Community() {
  return (
    <section id="community" className="relative py-32">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-orange-900/20 via-black to-black" />
      
      <div className="relative z-10 container mx-auto px-4">
        <div className="max-w-xl mx-auto text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-orange-400 to-amber-300">
            Join Our Community
          </h2>
          <p className="text-gray-400">
            Connect with fellow developers and stay updated with the latest features
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <a 
            href="https://discord.gg/3vt9wWn22U" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="group relative"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-orange-500/5 to-amber-500/5 rounded-2xl blur-xl transition-opacity opacity-0 group-hover:opacity-100" />
            <div className="relative p-8 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 hover:border-orange-500/20 transition-all">
              <MessageSquare className="w-8 h-8 text-orange-400 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Discord Community</h3>
              <p className="text-gray-400">Join our Discord server for support, updates, and to connect with other users.</p>
            </div>
          </a>

          <div className="group relative">
            <div className="absolute inset-0 bg-gradient-to-r from-orange-500/5 to-amber-500/5 rounded-2xl blur-xl transition-opacity opacity-0 group-hover:opacity-100" />
            <div className="relative p-8 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10">
              <Github className="w-8 h-8 text-orange-400 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Script Hub</h3>
              <p className="text-gray-400">Sorry, our script hub is currently down for work.</p>
            </div>
          </div>
        </div>

        <div className="mt-16 text-center">
          <div className="inline-flex items-center gap-4 px-6 py-3 bg-gradient-to-r from-orange-500/10 to-transparent rounded-full">
            <Users className="w-5 h-5 text-orange-400" />
            <span className="text-orange-400">Join over 50,000+ active users</span>
          </div>
        </div>
      </div>
    </section>
  );
}