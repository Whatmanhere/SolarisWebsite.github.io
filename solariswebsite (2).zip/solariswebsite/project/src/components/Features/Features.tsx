import React from 'react';
import { Shield, Zap, Code2, Lock, Sparkles, Cpu } from 'lucide-react';
import { FeatureCard } from './FeatureCard';

const features = [
  {
    icon: Shield,
    title: "Undetectable",
    description: "Advanced protection system keeps you safe while executing scripts"
  },
  {
    icon: Cpu,
    title: "Quantum Injection",
    description: "Next-generation injection method ensures maximum compatibility"
  },
  {
    icon: Code2,
    title: "Script Library",
    description: "Access to thousands of pre-made scripts and tools"
  },
  {
    icon: Lock,
    title: "Secure Updates",
    description: "Regular updates to maintain compatibility and security"
  },
  {
    icon: Sparkles,
    title: "Debug Console",
    description: "Advanced debugging tools for script development"
  },
  {
    icon: Zap,
    title: "Fast Execution",
    description: "Lightning-fast script execution engine"
  }
];

export function Features() {
  return (
    <section id="features" className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-orange-900/20 via-black to-black" />
      
      <div className="relative z-10 container mx-auto px-4">
        <div className="max-w-xl mx-auto text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-orange-400 to-amber-300">
            Cutting-Edge Features
          </h2>
          <p className="text-gray-400">
            Experience the next evolution in Roblox execution with our advanced feature set
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <FeatureCard key={index} {...feature} />
          ))}
        </div>
      </div>
    </section>
  );
}