import React from 'react';
import { Code2, Star, Download } from 'lucide-react';

export function Scripts() {
  const scripts = [
    {
      name: "Arsenal Pro",
      category: "FPS",
      downloads: "15k+",
      rating: 4.9
    },
    {
      name: "Blox Fruits",
      category: "Adventure",
      downloads: "20k+",
      rating: 4.8
    },
    {
      name: "Adopt Me",
      category: "RPG",
      downloads: "25k+",
      rating: 4.7
    }
  ];

  return (
    <section id="scripts" className="py-20 bg-gradient-to-b from-blue-900/20 via-blue-900/20 to-blue-900/20">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 bg-clip-text text-transparent bg-gradient-to-r from-blue-300 to-cyan-300">
          Popular Scripts
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {scripts.map((script, index) => (
            <div key={index} className="bg-gradient-to-br from-blue-900/20 to-blue-800/10 rounded-lg p-6 border border-blue-500/20">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-xl font-semibold text-white">{script.name}</h3>
                  <span className="text-blue-400 text-sm">{script.category}</span>
                </div>
                <Code2 className="w-6 h-6 text-blue-400" />
              </div>
              <div className="flex justify-between items-center mt-4">
                <div className="flex items-center gap-2">
                  <Download className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-400">{script.downloads}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                  <span className="text-gray-400">{script.rating}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}