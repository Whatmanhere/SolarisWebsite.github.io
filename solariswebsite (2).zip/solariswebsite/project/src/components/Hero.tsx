import React from 'react';
import { Download, Sparkles, Shield, AlertCircle, Cpu } from 'lucide-react';

export function Hero() {
  return (
    <div className="relative min-h-screen flex items-center overflow-hidden">
      {/* Cyberpunk background */}
      <div className="absolute inset-0 cyber-grid opacity-20" />
      <div className="absolute inset-0 hexagon-bg opacity-30" />
      
      {/* Animated lines */}
      <div className="absolute inset-0">
        <div className="absolute h-px w-full top-1/4 bg-gradient-to-r from-transparent via-purple-500 to-transparent animate-pulse" />
        <div className="absolute h-px w-full top-2/4 bg-gradient-to-r from-transparent via-purple-500 to-transparent animate-pulse delay-100" />
        <div className="absolute h-px w-full top-3/4 bg-gradient-to-r from-transparent via-purple-500 to-transparent animate-pulse delay-200" />
      </div>

      <div className="relative z-10 container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-900/30 rounded-full border border-purple-500/30">
              <Cpu className="w-5 h-5 text-purple-400" />
              <span className="text-purple-400 font-medium">Next-Gen Technology</span>
            </div>

            <div className="relative">
              <h1 className="text-6xl md:text-7xl font-bold leading-tight">
                <span className="block text-white opacity-90">Power</span>
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600 neon-text">
                  Unleashed
                </span>
              </h1>
              <div className="absolute -inset-1 bg-purple-500/20 blur-xl -z-10" />
            </div>

            <p className="text-lg text-gray-400 max-w-xl">
              Break through limitations with Solaris - the future of Roblox execution.
              Engineered for performance, built for dominance.
            </p>

            <div className="flex items-center gap-6 bg-purple-900/20 backdrop-blur-sm rounded-2xl p-4 border border-purple-500/20">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-purple-400" />
                <span className="font-bold text-purple-400">81% UNC</span>
              </div>
              <div className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-yellow-400" />
                <span className="text-yellow-400">Under work</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="https://discord.gg/3vt9wWn22U"
                target="_blank"
                rel="noopener noreferrer"
                className="group relative px-8 py-4 bg-purple-600 rounded-xl font-semibold text-white transition-all flex items-center justify-center gap-2 overflow-hidden neon-glow"
              >
                <Download className="w-5 h-5 group-hover:translate-y-0.5 transition-transform" />
                <span>Initialize Download</span>
              </a>
              <button
                className="px-8 py-4 bg-purple-900/20 hover:bg-purple-900/30 border border-purple-500/20 rounded-xl font-semibold transition-all flex items-center justify-center gap-2"
              >
                <Sparkles className="w-5 h-5" />
                <span>View Documentation</span>
              </button>
            </div>
          </div>

          <div className="hidden md:block relative">
            <div className="absolute inset-0 bg-purple-500 rounded-full blur-[100px] opacity-20 animate-pulse" />
            <div className="relative aspect-square rounded-lg border border-purple-500/20 bg-purple-900/20 backdrop-blur-sm p-8">
              <div className="absolute inset-0 cyber-grid opacity-20" />
              <div className="h-full w-full flex items-center justify-center">
                <Cpu className="w-32 h-32 text-purple-400 animate-pulse" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}