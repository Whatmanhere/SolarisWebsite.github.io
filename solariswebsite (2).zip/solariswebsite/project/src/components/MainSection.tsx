import React, { useState } from 'react';
import { Shield, Download, Sparkles, CheckCircle2, AlertCircle, Users, ChevronDown, AlertTriangle } from 'lucide-react';
import { FeaturesModal } from './FeaturesModal';

export function MainSection() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showError, setShowError] = useState(false);

  const handleDownload = () => {
    setShowError(true);
    setTimeout(() => setShowError(false), 3000);
  };

  const scrollToFeatures = () => {
    document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <main className="relative">
      {/* Hero Section */}
      <section className="min-h-screen pt-32">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl" />
        </div>

        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            {/* Status Indicators */}
            <div className="flex flex-wrap gap-4 mb-12">
              <div className="flex-1 bg-blue-950/50 backdrop-blur-sm rounded-2xl p-4 border border-blue-400/20">
                <div className="flex items-center gap-3">
                  <div className="bg-blue-500/20 p-2.5 rounded-lg">
                    <Shield className="w-6 h-6 text-blue-400" />
                  </div>
                  <div>
                    <div className="text-sm text-blue-300 mb-1">Security Status</div>
                    <div className="text-xl font-bold text-blue-400">100% UNC</div>
                  </div>
                </div>
              </div>
              
              <div className="flex-1 bg-blue-950/50 backdrop-blur-sm rounded-2xl p-4 border border-blue-400/20">
                <div className="flex items-center gap-3">
                  <div className="bg-emerald-500/20 p-2.5 rounded-lg">
                    <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                  </div>
                  <div>
                    <div className="text-sm text-emerald-300 mb-1">System Status</div>
                    <div className="text-xl font-bold text-emerald-400">Working</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Main Content */}
            <div className="text-center mb-12">
              <h1 className="text-6xl md:text-7xl font-bold mb-6">
                <span className="block text-blue-100 mb-2">Next Level</span>
                <span className="bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
                  Execution
                </span>
              </h1>
              <p className="text-lg text-blue-200/80 max-w-2xl mx-auto mb-8">
                Experience unparalleled power with Solaris - pushing the boundaries
                of what's possible in Roblox execution.
              </p>
            </div>

            {/* Error Message */}
            {showError && (
              <div className="fixed top-4 right-4 bg-red-500/90 text-white px-6 py-3 rounded-lg shadow-lg flex items-center gap-2 animate-fadeIn">
                <AlertCircle className="w-5 h-5" />
                Couldn't get exact link, sorry!
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
              <button
                onClick={handleDownload}
                className="group relative inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-blue-600 to-blue-500 rounded-xl overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-blue-600 translate-y-full group-hover:translate-y-0 transition-transform" />
                <Download className="w-5 h-5 relative z-10" />
                <span className="font-semibold relative z-10">Download Solaris</span>
              </button>
              
              <button 
                onClick={() => setIsModalOpen(true)}
                className="inline-flex items-center gap-2 px-8 py-4 bg-blue-950/50 hover:bg-blue-900/50 border border-blue-500/30 rounded-xl transition-colors"
              >
                <Sparkles className="w-5 h-5 text-blue-400" />
                <span className="font-semibold text-blue-200">View Features</span>
              </button>
            </div>

            {/* Scroll Indicator */}
            <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 cursor-pointer" onClick={scrollToFeatures}>
              <span className="text-blue-400/80 text-sm">Scroll to explore</span>
              <ChevronDown className="w-6 h-6 text-blue-400 animate-bounce" />
            </div>
          </div>
        </div>
      </section>

      {/* Executor Showcase Section */}
      <section className="min-h-screen bg-gradient-to-b from-transparent to-blue-900/20 py-32" id="features">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col lg:flex-row items-center gap-12">
              <div className="flex-1 space-y-6">
                <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-blue-300 bg-clip-text text-transparent">
                  The Best Executor
                </h2>
                <p className="text-lg text-blue-200/80">
                  Experience unmatched performance and reliability with our next-generation 
                  Roblox executor. Built with advanced technology to ensure maximum compatibility 
                  and security.
                </p>
              </div>
              <div className="flex-1">
                <div className="relative group">
                  <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 to-blue-300 rounded-xl blur opacity-30 group-hover:opacity-50 transition duration-500"></div>
                  <img 
                    src="https://cdn.discordapp.com/attachments/1312815265792135269/1314961449122140250/image.png?ex=67565588&is=67550408&hm=29433d41a58dafcba25cf51e0f29307a55e8b5e95233dabe62c333956ab3d99a&" 
                    alt="Solaris Executor" 
                    className="relative rounded-xl shadow-2xl transform transition duration-500 group-hover:scale-[1.02]"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trusted Developers Section */}
      <section className="py-32 bg-gradient-to-b from-blue-900/20 to-transparent">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="flex items-center justify-center mb-8">
              <div className="bg-blue-500/20 p-3 rounded-full">
                <Users className="w-8 h-8 text-blue-400" />
              </div>
            </div>
            <h2 className="text-4xl font-bold mb-6 bg-gradient-to-r from-blue-400 to-blue-300 bg-clip-text text-transparent">
              Trusted Developers
            </h2>
            <p className="text-lg text-blue-200/80 mb-8">
              Our team consists of experienced developers who are passionate about creating
              the most secure and reliable executor. With years of experience in Roblox
              development, we ensure the highest quality and safety for our users.
            </p>
            <div className="bg-blue-950/50 backdrop-blur-sm rounded-2xl p-8 border border-blue-400/20">
              <p className="text-blue-300">
                "Security and reliability are our top priorities. We continuously work to
                provide the best possible experience for our users while maintaining the
                highest standards of safety."
              </p>
            </div>

            {/* Disclaimer */}
            <div className="mt-8 flex items-center justify-center gap-2 text-yellow-400/80 text-sm">
              <AlertTriangle className="w-4 h-4" />
              <span>We are not responsible for any banned accounts.</span>
            </div>
          </div>
        </div>
      </section>

      <FeaturesModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </main>
  );
}