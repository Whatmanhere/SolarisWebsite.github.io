import React from 'react';
import { Code2, Terminal } from 'lucide-react';

interface FloatingElementsProps {
  isVisible: boolean;
}

export function FloatingElements({ isVisible }: FloatingElementsProps) {
  return (
    <>
      {/* Developer Credits */}
      <div className={`fixed bottom-4 right-4 transition-all duration-500 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}>
        <div className="flex items-center gap-3 bg-blue-950/80 backdrop-blur-sm border border-blue-500/20 rounded-lg p-3">
          <Code2 className="w-4 h-4 text-blue-400" />
          <span className="text-sm text-blue-300">nrzxxl | Website Developer</span>
          <span className="text-xs text-blue-400/60">© 2024 Console.dev</span>
        </div>
      </div>

      {/* Legal Notice */}
      <div className={`fixed bottom-4 left-4 transition-all duration-500 delay-100 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}>
        <div className="flex items-center gap-3 bg-blue-950/80 backdrop-blur-sm border border-blue-500/20 rounded-lg p-3">
          <Terminal className="w-4 h-4 text-blue-400" />
          <span className="text-xs text-blue-300">Protected by Console.dev™ for Solaris</span>
        </div>
      </div>
    </>
  );
}