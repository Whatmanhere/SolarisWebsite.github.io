import React from 'react';
import { Star, Download } from 'lucide-react';

interface ScriptCardProps {
  name: string;
  category: string;
  downloads: string;
  rating: number;
}

export function ScriptCard({ name, category, downloads, rating }: ScriptCardProps) {
  return (
    <div className="group relative">
      <div className="absolute inset-0 bg-gradient-to-r from-orange-500/5 to-amber-500/5 rounded-2xl blur-xl transition-opacity opacity-0 group-hover:opacity-100" />
      <div className="relative overflow-hidden rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 hover:border-orange-500/20 transition-all">
        <div className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="text-xl font-semibold text-white mb-1">{name}</h3>
              <span className="text-orange-400 text-sm">{category}</span>
            </div>
            <div className="px-3 py-1 bg-orange-500/10 rounded-full">
              <Star className="w-5 h-5 text-orange-400 fill-orange-400" />
            </div>
          </div>
          
          <div className="flex justify-between items-center mt-6">
            <div className="flex items-center gap-2">
              <Download className="w-4 h-4 text-gray-400" />
              <span className="text-gray-400">{downloads}</span>
            </div>
            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
              <span className="text-gray-400">{rating}</span>
            </div>
          </div>
        </div>
        
        <div className="h-1 w-full bg-gradient-to-r from-orange-500 to-amber-500 transform origin-left scale-x-0 group-hover:scale-x-100 transition-transform" />
      </div>
    </div>
  );
}