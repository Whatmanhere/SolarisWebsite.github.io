import React from 'react';
import { ScriptCard } from './ScriptCard';

const scripts = [
  {
    name: "Arsenal Pro",
    category: "FPS Enhancement",
    downloads: "15k+",
    rating: 4.9
  },
  {
    name: "Blox Fruits",
    category: "Adventure Boost",
    downloads: "20k+",
    rating: 4.8
  },
  {
    name: "Adopt Me",
    category: "RPG Automation",
    downloads: "25k+",
    rating: 4.7
  }
];

export function Scripts() {
  return (
    <section id="scripts" className="relative py-32">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-orange-900/20 via-black to-black" />
      
      <div className="relative z-10 container mx-auto px-4">
        <div className="max-w-xl mx-auto text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-orange-400 to-amber-300">
            Premium Scripts
          </h2>
          <p className="text-gray-400">
            Access our curated collection of high-performance scripts
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {scripts.map((script, index) => (
            <ScriptCard key={index} {...script} />
          ))}
        </div>
      </div>
    </section>
  );
}