import React, { useState, useEffect } from 'react';
import { Sun, Download, Users, Code2, BookOpen } from 'lucide-react';
import { NavLink } from './NavLink';

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`fixed w-full top-0 z-50 transition-all duration-300 ${
        isScrolled ? 'py-4 bg-black/80 backdrop-blur-xl border-b border-white/5' : 'py-6'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="absolute inset-0 bg-orange-400 blur-lg opacity-20 animate-pulse" />
              <Sun className="relative z-10 w-8 h-8 text-orange-400" />
            </div>
            <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-orange-400 to-amber-300">
              Solaris
            </span>
          </div>
          
          <nav className="hidden md:flex items-center gap-2">
            <NavLink href="#features" icon={Code2}>Features</NavLink>
            <NavLink href="#scripts" icon={BookOpen}>Scripts</NavLink>
            <NavLink href="#community" icon={Users}>Community</NavLink>
            <a 
              href="https://discord.gg/3vt9wWn22U" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="ml-4 px-6 py-2 bg-gradient-to-r from-orange-500 to-amber-500 rounded-lg font-medium hover:opacity-90 transition-all flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              Download
            </a>
          </nav>
        </div>
      </div>
    </header>
  );
}