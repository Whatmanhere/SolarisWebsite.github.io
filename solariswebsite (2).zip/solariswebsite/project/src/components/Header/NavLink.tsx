import React from 'react';
import { LucideIcon } from 'lucide-react';

interface NavLinkProps {
  href: string;
  icon: LucideIcon;
  children: React.ReactNode;
}

export function NavLink({ href, icon: Icon, children }: NavLinkProps) {
  return (
    <a 
      href={href} 
      className="group flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-white/5 transition-colors"
    >
      <Icon className="w-4 h-4 text-orange-400 group-hover:rotate-12 transition-transform" />
      <span className="font-medium">{children}</span>
    </a>
  );
}