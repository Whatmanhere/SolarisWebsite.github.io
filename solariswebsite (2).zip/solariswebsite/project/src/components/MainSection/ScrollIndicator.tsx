import React from 'react';
import { ChevronDown } from 'lucide-react';

export function ScrollIndicator() {
  const scrollToFeatures = () => {
    document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div 
      className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 cursor-pointer" 
      onClick={scrollToFeatures}
    >
      <span className="text-blue-400/80 text-sm">Scroll to explore</span>
      <ChevronDown className="w-6 h-6 text-blue-400 animate-bounce" />
    </div>
  );
}