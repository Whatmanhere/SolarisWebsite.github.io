import React from 'react';
import { Download } from 'lucide-react';

export function DownloadButton() {
  return (
    <a
      href="https://example.com"
      target="_blank"
      rel="noopener noreferrer"
      className="group relative inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-blue-600 to-blue-500 rounded-xl overflow-hidden"
    >
      <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-blue-600 translate-y-full group-hover:translate-y-0 transition-transform" />
      <Download className="w-5 h-5 relative z-10" />
      <span className="font-semibold relative z-10">Download Solaris</span>
    </a>
  );
}