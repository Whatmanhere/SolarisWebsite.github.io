import React, { useState } from 'react';
import { Sparkles } from 'lucide-react';
import { StatusIndicators } from './StatusIndicators';
import { MainContent } from './MainContent';
import { DownloadButton } from './DownloadButton';
import { ScrollIndicator } from './ScrollIndicator';
import { ExecutorShowcase } from './ExecutorShowcase';
import { TrustedDevelopers } from './TrustedDevelopers';
import { FeaturesModal } from '../FeaturesModal';

export function MainSection() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <main className="relative">
      {/* Hero Section */}
      <section className="min-h-screen pt-32">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl" />
        </div>

        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <StatusIndicators />
            <MainContent />

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
              <DownloadButton />
              
              <button 
                onClick={() => setIsModalOpen(true)}
                className="inline-flex items-center gap-2 px-8 py-4 bg-blue-950/50 hover:bg-blue-900/50 border border-blue-500/30 rounded-xl transition-colors"
              >
                <Sparkles className="w-5 h-5 text-blue-400" />
                <span className="font-semibold text-blue-200">View Features</span>
              </button>
            </div>

            <ScrollIndicator />
          </div>
        </div>
      </section>

      <ExecutorShowcase />
      <TrustedDevelopers />

      <FeaturesModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </main>
  );
}