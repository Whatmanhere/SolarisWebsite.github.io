import React from 'react';

export function MainContent() {
  return (
    <div className="text-center mb-12">
      <h1 className="text-6xl md:text-7xl font-bold mb-6">
        <span className="block text-blue-100 mb-2">Next Level</span>
        <span className="bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
          Execution
        </span>
      </h1>
      <p className="text-lg text-blue-200/80 max-w-2xl mx-auto mb-8">
        Experience unparalleled power with Solaris - pushing the boundaries
        of what's possible in Roblox execution.
      </p>
    </div>
  );
}