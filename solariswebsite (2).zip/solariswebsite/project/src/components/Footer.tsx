import React from 'react';
import { MessageSquare, Shield, AlertTriangle, Youtube } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gradient-to-b from-blue-900/20 to-black py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          <div>
            <h3 className="text-xl font-semibold mb-4 text-blue-300">Contact</h3>
            <div className="space-y-2">
              <a 
                href="https://discord.gg/3vt9wWn22U" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-400 hover:text-blue-400 transition-colors"
              >
                <MessageSquare className="w-4 h-4" />
                Discord Community
              </a>
              <a 
                href="https://www.youtube.com/@chemicalexecutor" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-400 hover:text-blue-400 transition-colors"
              >
                <Youtube className="w-4 h-4" />
                YouTube Channel
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-4 text-blue-300">Legal</h3>
            <div className="space-y-2">
              <p className="text-gray-400">© 2024 Chemical.lol</p>
              <p className="text-gray-400">All rights reserved</p>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-4 text-blue-300">Security</h3>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-gray-400">
                <Shield className="w-4 h-4 text-green-400" />
                <span>Secure Execution</span>
              </div>
              <div className="flex items-center gap-2 text-gray-400">
                <AlertTriangle className="w-4 h-4 text-yellow-400" />
                <span>Use at your own risk</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-blue-900/30 pt-8">
          <p className="text-center text-gray-500 text-sm">
            Chemical.lol is not affiliated with Roblox Corporation. This tool is for educational purposes only.
          </p>
        </div>
      </div>
    </footer>
  );
}