import React from 'react';
import { Download, Sparkles, Cpu } from 'lucide-react';
import { StatusBadge } from './StatusBadge';

export function HeroContent() {
  return (
    <div className="space-y-8">
      <div className="inline-flex items-center gap-3 px-5 py-3 bg-blue-950/40 rounded-full border border-blue-400/20">
        <Cpu className="w-5 h-5 text-blue-400" />
        <span className="text-blue-300 font-medium">Next-Gen Technology</span>
      </div>

      <div className="relative">
        <h1 className="text-6xl md:text-7xl font-bold leading-tight">
          <span className="block text-blue-100">Power</span>
          <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-300 neon-text">
            Unleashed
          </span>
        </h1>
        <div className="absolute -inset-1 bg-blue-500/20 blur-xl -z-10" />
      </div>

      <p className="text-lg text-blue-200/80 max-w-xl">
        Break through limitations with Solaris - the future of Roblox execution.
        Engineered for performance, built for dominance.
      </p>

      <StatusBadge />

      <div className="flex flex-col sm:flex-row gap-4">
        <a
          href="https://discord.gg/3vt9wWn22U"
          target="_blank"
          rel="noopener noreferrer"
          className="group relative px-8 py-4 bg-gradient-to-r from-blue-500 to-blue-400 rounded-xl font-semibold text-white transition-all flex items-center justify-center gap-2 hover:opacity-90"
        >
          <div className="absolute inset-0 bg-blue-300/20 rounded-xl blur opacity-0 group-hover:opacity-100 transition-opacity" />
          <Download className="w-5 h-5 relative z-10 group-hover:translate-y-0.5 transition-transform" />
          <span className="relative z-10">Initialize Download</span>
        </a>
        <button className="px-8 py-4 bg-blue-950/40 hover:bg-blue-900/40 border border-blue-400/20 rounded-xl font-semibold transition-all flex items-center justify-center gap-2 group">
          <Sparkles className="w-5 h-5 text-blue-400 group-hover:rotate-12 transition-transform" />
          <span className="text-blue-200">View Documentation</span>
        </button>
      </div>
    </div>
  );
}