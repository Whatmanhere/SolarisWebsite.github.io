import React from 'react';
import { Cpu } from 'lucide-react';
import { HeroContent } from './HeroContent';

export function Hero() {
  return (
    <div className="relative min-h-screen flex items-center overflow-hidden">
      {/* Cyberpunk background */}
      <div className="absolute inset-0 cyber-grid opacity-20" />
      <div className="absolute inset-0 hexagon-bg opacity-30" />
      
      {/* Animated lines */}
      <div className="absolute inset-0">
        <div className="absolute h-px w-full top-1/4 bg-gradient-to-r from-transparent via-blue-500 to-transparent animate-pulse" />
        <div className="absolute h-px w-full top-2/4 bg-gradient-to-r from-transparent via-blue-500 to-transparent animate-pulse delay-100" />
        <div className="absolute h-px w-full top-3/4 bg-gradient-to-r from-transparent via-blue-500 to-transparent animate-pulse delay-200" />
      </div>

      <div className="relative z-10 container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <HeroContent />

          <div className="hidden md:block relative">
            <div className="absolute inset-0 bg-blue-500 rounded-full blur-[100px] opacity-20 animate-pulse" />
            <div className="relative aspect-square rounded-lg border border-blue-500/20 bg-blue-900/20 backdrop-blur-sm p-8">
              <div className="absolute inset-0 cyber-grid opacity-20" />
              <div className="h-full w-full flex items-center justify-center">
                <Cpu className="w-32 h-32 text-blue-400 animate-pulse" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}