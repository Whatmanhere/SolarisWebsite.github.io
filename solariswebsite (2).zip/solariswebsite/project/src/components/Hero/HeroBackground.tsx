import React from 'react';

export function HeroBackground() {
  return (
    <>
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-900/30 via-black to-black" />
      <div className="absolute inset-0">
        <div className="absolute h-px w-full top-1/4 bg-gradient-to-r from-transparent via-blue-500 to-transparent animate-pulse" />
        <div className="absolute h-px w-full top-2/4 bg-gradient-to-r from-transparent via-blue-500 to-transparent animate-pulse delay-100" />
        <div className="absolute h-px w-full top-3/4 bg-gradient-to-r from-transparent via-blue-500 to-transparent animate-pulse delay-200" />
      </div>
      <div className="absolute inset-0">
        <div className="absolute w-full h-full bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJub25lIiBzdHJva2U9IiMzYjgyZjYyMCIgc3Ryb2tlLXdpZHRoPSIyIi8+PC9zdmc+')] opacity-20" />
      </div>
      <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-blue-500/10 blur-[120px] rounded-full animate-pulse" />
      <div className="absolute bottom-0 left-0 w-1/2 h-1/2 bg-blue-500/10 blur-[120px] rounded-full animate-pulse delay-700" />
    </>
  );
}