import React from 'react';
import { Shield, CheckCircle } from 'lucide-react';

export function StatusBadge() {
  return (
    <div className="flex flex-col sm:flex-row items-center gap-6 bg-blue-950/40 backdrop-blur-sm rounded-2xl p-6 border border-blue-400/20">
      <div className="flex items-center gap-4 bg-blue-900/30 px-6 py-3 rounded-xl border border-blue-500/20">
        <Shield className="w-7 h-7 text-blue-400" />
        <div>
          <div className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-blue-300 bg-clip-text text-transparent">
            100% UNC
          </div>
        </div>
      </div>

      <div className="flex items-center gap-4 bg-blue-900/30 px-6 py-3 rounded-xl border border-blue-500/20">
        <CheckCircle className="w-7 h-7 text-blue-400" />
        <div>
          <div className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-blue-300 bg-clip-text text-transparent">
            Working
          </div>
        </div>
      </div>
    </div>
  );
}