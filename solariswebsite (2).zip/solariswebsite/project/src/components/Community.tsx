import React from 'react';
import { Users, MessageSquareMore, Github } from 'lucide-react';

export function Community() {
  return (
    <section id="community" className="py-20 bg-gradient-to-b from-blue-900/20 via-blue-900/20 to-blue-900/20">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 bg-clip-text text-transparent bg-gradient-to-r from-blue-300 to-cyan-300">
          Join Our Community
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <a href="https://discord.gg/3vt9wWn22U" target="_blank" rel="noopener noreferrer" className="group">
            <div className="p-6 rounded-lg bg-white/5 backdrop-blur-sm border border-blue-500/20 hover:border-blue-500/40 transition-all">
              <MessageSquareMore className="w-8 h-8 text-blue-400 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Discord Community</h3>
              <p className="text-gray-400">Join our Discord server for support, updates, and to connect with other users.</p>
            </div>
          </a>

          <div className="group">
            <div className="p-6 rounded-lg bg-white/5 backdrop-blur-sm border border-blue-500/20">
              <Github className="w-8 h-8 text-blue-500 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Script Hub</h3>
              <p className="text-gray-400">Sorry, our script hub is currently down for work.</p>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          <div className="inline-flex items-center gap-4 px-6 py-3 bg-blue-600/20 rounded-full">
            <Users className="w-5 h-5 text-blue-400" />
            <span className="text-blue-300">Join over 50,000+ active users</span>
          </div>
        </div>
      </div>
    </section>
  );
}