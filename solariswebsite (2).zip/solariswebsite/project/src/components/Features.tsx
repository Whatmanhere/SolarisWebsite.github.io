import React from 'react';
import { Shield, TestTube2, Zap, Code2, Lock, Sparkles } from 'lucide-react';

export function Features() {
  const features = [
    {
      icon: <Shield className="w-6 h-6 text-blue-400" />,
      title: "Undetectable",
      description: "Advanced protection system keeps you safe while executing scripts"
    },
    {
      icon: <TestTube2 className="w-6 h-6 text-blue-400" />,
      title: "Chemical Injection",
      description: "Our proprietary injection method ensures maximum compatibility"
    },
    {
      icon: <Code2 className="w-6 h-6 text-blue-400" />,
      title: "Script Library",
      description: "Access to thousands of pre-made scripts and tools"
    },
    {
      icon: <Lock className="w-6 h-6 text-blue-400" />,
      title: "Secure Updates",
      description: "Regular updates to maintain compatibility and security"
    },
    {
      icon: <Sparkles className="w-6 h-6 text-blue-400" />,
      title: "Debug Console",
      description: "Advanced debugging tools for script development"
    },
    {
      icon: <Zap className="w-6 h-6 text-blue-400" />,
      title: "Fast Execution",
      description: "Lightning-fast script execution engine"
    }
  ];

  return (
    <section id="features" className="bg-gradient-to-b from-black via-blue-900/20 to-blue-900/20 py-20">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 bg-clip-text text-transparent bg-gradient-to-r from-blue-300 to-cyan-300">
          Premium Features
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="p-6 rounded-lg bg-white/5 backdrop-blur-sm border border-blue-500/20 hover:border-blue-500/40 transition-all">
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
              <p className="text-gray-400">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}