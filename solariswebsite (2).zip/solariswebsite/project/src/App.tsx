import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { MainSection } from './components/MainSection';
import { FloatingElements } from './components/FloatingElements';

function App() {
  const [showFloatingElements, setShowFloatingElements] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowFloatingElements(window.scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-[#040B1C] text-white overflow-hidden">
      <div className="fixed inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-900/20 via-[#040B1C] to-[#040B1C]" />
      <div className="relative z-10">
        <Header />
        <MainSection />
        <FloatingElements isVisible={showFloatingElements} />
      </div>
    </div>
  );
}

export default App;